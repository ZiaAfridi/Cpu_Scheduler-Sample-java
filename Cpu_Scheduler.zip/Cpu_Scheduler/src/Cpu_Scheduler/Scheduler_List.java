/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Cpu_Scheduler;
import java.util.Random;

/**
 *
 * @author zia
 */
class Scheduler_List extends Thread{
    
    @Override
    public void run() {
        try{
        Thread.sleep(500);
        }catch(InterruptedException ex){}
        
    }
    Scheduler_List list;
    Cpu_Scheduler head=null;
    Cpu_Scheduler tail = null;
    
    public int totalTime(){
    int tTime=0;
    Cpu_Scheduler process = head;
    while(process != null)
    {
        tTime = tTime + process.getP_exetime();
       process =process.getNext();
    }
    return tTime;
    }

      
    
     
    public void Process_Data(int p_id,String p_name, int p_exetime, int p_inttrupts, String p_status, int p_priority)
    {
        Cpu_Scheduler process = new Cpu_Scheduler();
        process.p_id = p_id;
        process.p_name = p_name;
        process.p_exetime = p_exetime;
        process.p_inttrupts = p_inttrupts;
        process.p_status = p_status;
        process.p_priority = p_priority;
        
        if(head == null)
        {
            head = process;
            tail = process;
        }
        else{
                 
            process.setNext(head);
            head = process;
        }
    }
    
   
    
    
    public void Waiting(Cpu_Scheduler process )
    {
        if(process.getP_inttrupts() > 0){
            if( process.getP_exetime()== 3 || process.getP_exetime() == 7 || 
               process.getP_exetime() == 9 || process.getP_exetime() == 11 || process.getP_exetime() == 15 )
            {
                process.setP_status("Waiting");
            }
        }else{
            if(process.getP_exetime() == 5 ){
                process.setP_status("Waiting");
            }
        }
    }
   
    
    public void FCFS(){

             Cpu_Scheduler process = head;
             Cpu_Scheduler nextProcess = process.getNext();

                  while(nextProcess != null)
                  {
                      if(nextProcess.getP_exetime() != 0){
                          process = nextProcess;
                          nextProcess = nextProcess.getNext(); 
                      }else{
                          nextProcess = nextProcess.getNext();
                      }

                   }
                  if(process.getP_exetime() > 1){
                       process.setP_status("Running");
                       process.setP_exetime(process.getP_exetime() - 1 );
                       Waiting(process);
                  }else{
                      process.setP_exetime(0);
                      process.setP_inttrupts(0);
                      process.setP_status("Terminated");

                  }
        }
    
  
    
    public Cpu_Scheduler Priority(){
            Cpu_Scheduler process = head;
            Cpu_Scheduler nextprocess = process.getNext();

                while(nextprocess != null)
                {
                    if((nextprocess.getP_exetime() > 0) && (process.getP_priority() > nextprocess.getP_priority())){
                        process = nextprocess;
                        nextprocess = nextprocess.getNext(); 
                    }else{
                        nextprocess = nextprocess.getNext(); 
                    }
                 }
                if(process.getP_exetime() > 0){
                    process.setP_status("Runing");
                    
                    process.setP_exetime(process.getP_exetime() - 1 );
                    process.setP_priority(process.getP_priority()+1);
                    Waiting(process);
                }else{
                    process.setP_exetime(0);
                    process.setP_inttrupts(0);
                    process.setP_priority(0);
                    process.setP_status("Terminated");
                    Del(process.getP_id());
                    Terminated(process);
                }
                return process;
        }
             
    public void Sjf(){
  
         Cpu_Scheduler process = head;
        Cpu_Scheduler nextProcess = process.getNext();
        
            while(nextProcess != null)
            {
                
                if((nextProcess.getP_exetime() > 0) && (process.getP_exetime() > nextProcess.getP_exetime())){
                    process = nextProcess;
                    nextProcess = nextProcess.getNext(); 
                }else{
                    nextProcess = nextProcess.getNext(); 
                }
             }
           
          
        
            if(process.getP_exetime() > 1){
                 process.setP_status("Running");
                 process.setP_exetime(process.getP_exetime() - 1 );
                 Waiting(process);
            }else{
                process.setP_exetime(0);
                process.setP_inttrupts(0);
                process.setP_status("Terminated");  
               Del(process.getP_id());
               Terminated(process);
            }
           
    }
    public void Del(int target){
        
        Cpu_Scheduler fprocess = head;
        Cpu_Scheduler pprocess = head;
        
        while(fprocess != null){
                if(fprocess.getP_id() == target){
                break;
            }
            else{
                pprocess= fprocess;
                fprocess=fprocess.getNext();
            }
        }
        
        if(fprocess != null){
             if(fprocess == head)
                 {
                     head=head.getNext();
                 }
             else if(fprocess == tail){
                  tail=pprocess;
                  tail.setNext(fprocess);
                }
             else{
                   pprocess.setNext(fprocess.getNext());
             }
        }
    }
   
    
     public void Terminated(Cpu_Scheduler process)
    {
        Cpu_Scheduler temp = head;  
        if(head == null){
            Process_Data(process.getP_id(), process.getP_name(), process.getP_exetime(), process.getP_inttrupts(), process.getP_status(),process.getP_priority());
        }else{
        Cpu_Scheduler cprocess = new Cpu_Scheduler();
        cprocess.p_id = process.getP_id();
        cprocess.p_name = process.getP_name();
        cprocess.p_exetime = process.getP_exetime();
        cprocess.p_inttrupts = process.getP_inttrupts();
        cprocess.p_status = process.getP_status();
        cprocess.p_priority=process.getP_priority();
        
         tail.setNext(cprocess);
         tail = cprocess;
        }
    }
   
}