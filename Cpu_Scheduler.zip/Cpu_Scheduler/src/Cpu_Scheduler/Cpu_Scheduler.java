/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Cpu_Scheduler;

/**
 *
 * @author zia
 */
public class Cpu_Scheduler {
    
    int p_id,p_exetime,p_inttrupts,p_priority;
    String p_name,p_status;
    Cpu_Scheduler next;
    
    public Cpu_Scheduler() {
        this.p_id = 0;
        this.p_exetime = 0;
        this.p_inttrupts = 0;
        this.p_name = "";
        this.p_status = "";
        this.p_priority=0;
        this.next = null;
    }

    public Cpu_Scheduler(int p_id, int p_exetime, int p_inttrupts, int p_priority, String p_status, Cpu_Scheduler next) {
        this.p_id = p_id;
        this.p_exetime = p_exetime;
        this.p_inttrupts = p_inttrupts;
        this.p_priority = p_priority;
        this.p_status = p_status;
        this.next = next;
    }

    public int getP_id() {
        return p_id;
    }

    public void setP_id(int p_id) {
        this.p_id = p_id;
    }

    public int getP_exetime() {
        return p_exetime;
    }

    public void setP_exetime(int p_exetime) {
        this.p_exetime = p_exetime;
    }

    public int getP_inttrupts() {
        return p_inttrupts;
    }

    public void setP_inttrupts(int p_inttrupts) {
        this.p_inttrupts = p_inttrupts;
    }

    public int getP_priority() {
        return p_priority;
    }

    public void setP_priority(int p_priority) {
        this.p_priority = p_priority;
    }

    public String getP_name() {
        return p_name;
    }

    public void setP_name(String p_name) {
        this.p_name = p_name;
    }

    public String getP_status() {
        return p_status;
    }

    public void setP_status(String p_status) {
        this.p_status = p_status;
    }

    public Cpu_Scheduler getNext() {
        return next;
    }

    public void setNext(Cpu_Scheduler next) {
        this.next = next;
    }
    
    
}
